BEAUTY AI SOLUTIONS WEBSITE

Publish free using GitHub Pages:
1. Sign in/create an account at https://github.com
2. Create a NEW PUBLIC repository named beauty-ai-solutions-site
3. Choose Add file > Upload files and upload index.html
4. Click Commit changes
5. Open repository Settings > Pages
6. Under Build and deployment, choose Deploy from a branch
7. Select branch main and folder /(root), then Save
8. Wait a few minutes; the public URL will appear in Settings > Pages.

Before publishing:
- In index.html, replace YOUR_EMAIL_HERE with your real contact email.
- The contact form is a mailto demo, not a database-backed form.
- This is a promotional landing page, not a functioning AI skin-analysis service.
- On GitHub Free, the repository must be public for GitHub Pages. Avoid uploading private information.
